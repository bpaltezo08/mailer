<?php

	include "mailer.php";

	if(isset($_POST["email"])){
// 		SendMail($_POST["email"], "The books you have borrowed from the library are overdue. Kindly return the books as soon as possible.<br><br>Sincerely Yours, <br>Librarian");
		SendMail($_POST["email"] , Template("Reservation", "borrower", "Your churvalu eclavush mensuases anek anek trulalu jutsy si anes ni troo", "Librarian", "Dagupan City Public Library", "Tapuac Dagupan City Pangasinan"));
	}

?>