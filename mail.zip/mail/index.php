<?php

  
include('../db.php');
$email= $message= "";

$emailErr= $messageErr= "";


if(isset($_POST["submit"])){
	
	if(empty($_POST["email"])){
		$emailErr = "Required";
	}else{
		$email = $_POST["email"];
	}
	if(empty($_POST["message"])){
		$messageErr = "Required";
	}else{
		$message = $_POST["message"];
	}
	
	
	if( $email && $message){
	
		require'PHPMailer/PHPMailerAutoload.php';
		
		$mail = new PHPMailer;
		//$mail->SMTPDebug = 3;
		$mail->IsSMTP();
		$mail->Host = 'smtp.gmail.com';
		$mail->SMTPAuth = true;
		$mail->Username = 'dagupanlibrary@gmail.com';
		$mail->Password = 'library2019';
		$mail->SMTPSecure = 'tls';
		$mail->Port = 587;
		$mail->From = 'dagupan';
		$mail->FromName = 'Librarian';
		$mail->addAddress($email);
		$mail->isHTML(true);
		 $mail->Header = 'MIME-Version: 1.0\r\nt Content-Type: text/plain; charset=utf-8\r\n
	X-Priority: 1\r\n'; // importante to
	
		
		$mail->Subject = 'Dagupan City Public Library';
		$mail->Body = $message;
		
		if(!$mail->send()){
			echo'Message could not be sent.';
			echo'Mailer Error ' .$mail->ErrorInfo;
		}else{
			
		
	 $sql = "INSERT INTO send_email (`email`, `message`) VALUES ('$email', '$message')";
  $r = db::getInstance()->query($sql);
		
		
		
		echo"<script>window.location.href='index.php';</script>";

		}
				
	    }
		
}
?>

<style>
.error{
	color:red;
}
</style>
<script type = "application/javascript">

function isNumberKey(evt){
	
	var charCode = (evt.which) ? evt.which : event.keyCode
	
	if(charCode > 31 && (charCode <48 || charCode > 57))
		
	return false;
	
	return true;
	
}
</script>
<form method="POST">
   
  
  Email Address:<input type="text" name="email" value="<?php echo $email; ?>" placeholder="email"> <span class="error"><?php echo $emailErr; ?></span>
  <br>
   Message:<input type="text" name="message" value="<?php echo $message; ?>" placeholder="message"> <span class="error"><?php echo $messageErr; ?></span>
 
       <input type="submit" name="submit" value="submit">
  


</form>