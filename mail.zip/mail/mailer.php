<?php

	function SendMail($email, $message){

	$res = "";
	require'PHPMailer/PHPMailerAutoload.php';
		
	$mail = new PHPMailer;
	//$mail->SMTPDebug = 3;
	$mail->IsSMTP();
	$mail->Host = 'smtp.gmail.com';
	$mail->SMTPAuth = true;
	$mail->Username = 'dagupanlibrary@gmail.com';
	$mail->Password = 'library2019';
	$mail->SMTPSecure = 'tls';
	$mail->Port = 587;
	$mail->From = 'dagupan';
	$mail->FromName = 'Librarian';
	$mail->addAddress($email);
	$mail->isHTML(true);
	 $mail->Header = 'MIME-Version: 1.0\r\nt Content-Type: text/plain; charset=utf-8\r\n
	X-Priority: 1\r\n'; // importante to	
		
	$mail->Subject = 'Dagupan City Public Library';
	$mail->Body = $message;
	
	if(!$mail->send()){
		$res = 'Message could not be sent.';
		$res = 'Mailer Error ' .$mail->ErrorInfo;
	}else{
		$res = "Email sent";
	}

	return $res;
    }
    
    function Template($title, $dear, $content, $sender, $title2, $address){
       return  '<center>
    <h4>'.$title.'</h4>
    <br>
</center>
    <p>Dear '.$dear.',</p>
    <p style="text-indent:30px;">'.$content.'</p>
    <br><br>
    <p>Yours truly,</p>
    <p>'.$sender.'</p>
    <br><br>
<center>
    <h4>'.$title2.'</h4>
    <p>'.$address.'</p>
    <p><small style="color:blue;">* Please Do not reply to this message</small></p>
</center>';
    }

?>